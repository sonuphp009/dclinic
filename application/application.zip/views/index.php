<!DOCTYPE html>
<html>
<head>
	<?php $this->load->view('css');?>
</head>
<body>
<div class="wrapper">
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

<?php $this->load->view('navbar');?>
<?php $this->load->view('asid_bar');?>

</div>
<?php $this->load->view('javascript');?>

</body>
</html>