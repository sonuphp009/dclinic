<br/><br/>
<footer class="bg-light" style="
	padding: 10px;position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  color: black;
  text-align: left;">
    <strong>Copyright &copy; 2021-2022 <a href="http://clinicalsoftware.in">Sonu Thakare</a>.</strong>
    All rights reserved.
    
  </footer>
  